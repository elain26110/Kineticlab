KINETICLAB — VERSION 2
======================

Contenu :
- index.html : site statique responsive, sans dépendance externe.
- Bibliothèque interactive de 5 fiches pédagogiques.
- Recherche textuelle et filtres par type de structure.
- Interface en français, espagnol et anglais.
- Fiches détaillées : mécanisme, bilan clinique, principes de rééducation,
  retour au sport et points de vigilance.

Mise à jour :
Remplacer le fichier index.html actuellement publié par celui-ci dans le dépôt
GitHub connecté à Netlify. Netlify relancera automatiquement le déploiement.

Limites :
- Aucun compte utilisateur, favori, base de données ou contenu administrable
  n'est encore connecté.
- Les fiches sont des résumés pédagogiques initiaux, à compléter avec des
  références scientifiques vérifiées et une validation éditoriale.
- Ne pas utiliser comme substitut à une évaluation clinique ou médicale.
